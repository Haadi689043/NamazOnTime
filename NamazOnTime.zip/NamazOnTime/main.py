from kivy.app import App
from kivy.uix.label import Label
from kivy.core.audio import SoundLoader

class NamazOnTimeApp(App):
    def build(self):
        return Label(text="Namaz On Time")

if __name__ == "__main__":
    NamazOnTimeApp().run()