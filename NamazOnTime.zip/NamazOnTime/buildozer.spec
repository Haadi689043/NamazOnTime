[app]
title = Namaz On Time BY The Deen e Islam Studio!
package.name = namazontime
package.domain = org.deeneislam

source.dir = .
source.include_exts = py,mp3,png
version = 1.0

requirements = python3,kivy,requests,plyer,pycountry
orientation = portrait
icon.filename = icon.png

android.permissions = INTERNET,ACCESS_FINE_LOCATION
android.api = 31
android.minapi = 21
android.archs = arm64-v8a